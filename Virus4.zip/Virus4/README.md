how install Virus4\

{1} in termux
pkg install git -y
pkg install python2
git clone https://github.com/DEVBOSS1/Virus4
chmod +x *
python2 Virus4.py

{2} in kali linux and parrot os

