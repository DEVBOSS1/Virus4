#
# Copyright (c) 2015-2016 by Hypsurus <lllriiirlll123@gmail.com>
#
# See 'LICENSE' for copying
#


