#!/usr/bin/python3 -B
import base64 as b
data = lambda x: x(b'230A23205F5F696E69745F5F2E7079202D206A75737420706173730A230A0A706173730A')
exec (compile(data(b.b16decode),'<string>','exec'))